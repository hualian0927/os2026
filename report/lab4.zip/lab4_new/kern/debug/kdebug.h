#ifndef __KERN_DEBUG_KDEBUG_H__
#define __KERN_DEBUG_KDEBUG_H__

#include <defs.h>
#include <trap.h>

void print_kerninfo(void);
void print_stackframe(void);

#endif /* !__KERN_DEBUG_KDEBUG_H__ */
